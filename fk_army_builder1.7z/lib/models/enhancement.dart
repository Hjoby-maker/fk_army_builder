// models/enhancement.dart
class Enhancement {
  final String factionId;
  final String id;
  final String name;
  final int cost;
  final String detachment;
  final String detachmentId;
  final String legend;
  final String description;

  Enhancement({
    required this.factionId,
    required this.id,
    required this.name,
    required this.cost,
    required this.detachment,
    required this.detachmentId,
    required this.legend,
    required this.description,
  });

  factory Enhancement.fromCSV(List<String> row) {
    return Enhancement(
      factionId: row[0],
      id: row[1],
      name: row[2],
      cost: int.parse(row[3]),
      detachment: row[4],
      detachmentId: row[5],
      legend: row[6],
      description: row[7],
    );
  }
}