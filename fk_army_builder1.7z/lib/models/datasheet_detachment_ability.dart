// models/datasheet_detachment_ability.dart
class DatasheetDetachmentAbility {
  final String datasheetId;
  final String detachmentAbilityId;

  DatasheetDetachmentAbility({
    required this.datasheetId,
    required this.detachmentAbilityId,
  });

  factory DatasheetDetachmentAbility.fromCSV(List<String> row) {
    return DatasheetDetachmentAbility(
      datasheetId: row[0],
      detachmentAbilityId: row[1],
    );
  }
}