// models/datasheet_option.dart
class DatasheetOption {
  final String datasheetId;
  final int line;
  final String button;
  final String description;

  DatasheetOption({
    required this.datasheetId,
    required this.line,
    required this.button,
    required this.description,
  });

  factory DatasheetOption.fromCSV(List<String> row) {
    return DatasheetOption(
      datasheetId: row[0],
      line: int.parse(row[1]),
      button: row[2],
      description: row[3],
    );
  }
}