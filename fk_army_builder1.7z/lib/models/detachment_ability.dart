// models/detachment_ability.dart
class DetachmentAbility {
  final String id;
  final String factionId;
  final String name;
  final String legend;
  final String description;
  final String detachment;
  final String detachmentId;

  DetachmentAbility({
    required this.id,
    required this.factionId,
    required this.name,
    required this.legend,
    required this.description,
    required this.detachment,
    required this.detachmentId,
  });

  factory DetachmentAbility.fromCSV(List<String> row) {
    return DetachmentAbility(
      id: row[0],
      factionId: row[1],
      name: row[2],
      legend: row[3],
      description: row[4],
      detachment: row[5],
      detachmentId: row[6],
    );
  }
}