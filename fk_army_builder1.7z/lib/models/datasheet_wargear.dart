// models/datasheet_wargear.dart
class DatasheetWargear {
  final String datasheetId;
  final int line;
  final int lineInWargear;
  final String? dice;
  final String name;
  final String description;
  final String? range;
  final String type;
  final int attacks;
  final String ballisticSkill;
  final int strength;
  final int armorPenetration;
  final String damage;

  DatasheetWargear({
    required this.datasheetId,
    required this.line,
    required this.lineInWargear,
    this.dice,
    required this.name,
    required this.description,
    this.range,
    required this.type,
    required this.attacks,
    required this.ballisticSkill,
    required this.strength,
    required this.armorPenetration,
    required this.damage,
  });

  factory DatasheetWargear.fromCSV(List<String> row) {
    return DatasheetWargear(
      datasheetId: row[0],
      line: int.parse(row[1]),
      lineInWargear: int.parse(row[2]),
      dice: row[3].isNotEmpty ? row[3] : null,
      name: row[4],
      description: row[5],
      range: row[6].isNotEmpty ? row[6] : null,
      type: row[7],
      attacks: int.parse(row[8]),
      ballisticSkill: row[9],
      strength: int.parse(row[10]),
      armorPenetration: int.parse(row[11]),
      damage: row[12],
    );
  }
}