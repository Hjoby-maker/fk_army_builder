// models/datasheet_model.dart
class DatasheetModel {
  final String datasheetId;
  final int line;
  final String name;
  final String move;
  final int toughness;
  final String save;
  final String? invulnerableSave;
  final String? invulnerableSaveDescription;
  final int wounds;
  final String leadership;
  final int objectiveControl;
  final String baseSize;
  final String? baseSizeDescription;

  DatasheetModel({
    required this.datasheetId,
    required this.line,
    required this.name,
    required this.move,
    required this.toughness,
    required this.save,
    this.invulnerableSave,
    this.invulnerableSaveDescription,
    required this.wounds,
    required this.leadership,
    required this.objectiveControl,
    required this.baseSize,
    this.baseSizeDescription,
  });

  factory DatasheetModel.fromCSV(List<String> row) {
    return DatasheetModel(
      datasheetId: row[0],
      line: int.parse(row[1]),
      name: row[2],
      move: row[3],
      toughness: int.parse(row[4]),
      save: row[5],
      invulnerableSave: row[6].isNotEmpty ? row[6] : null,
      invulnerableSaveDescription: row[7].isNotEmpty ? row[7] : null,
      wounds: int.parse(row[8]),
      leadership: row[9],
      objectiveControl: int.parse(row[10]),
      baseSize: row[11],
      baseSizeDescription: row[12].isNotEmpty ? row[12] : null,
    );
  }
}