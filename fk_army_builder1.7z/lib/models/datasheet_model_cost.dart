// models/datasheet_model_cost.dart
class DatasheetModelCost {
  final String datasheetId;
  final int line;
  final String description;
  final int cost;

  DatasheetModelCost({
    required this.datasheetId,
    required this.line,
    required this.description,
    required this.cost,
  });

  factory DatasheetModelCost.fromCSV(List<String> row) {
    return DatasheetModelCost(
      datasheetId: row[0],
      line: int.parse(row[1]),
      description: row[2],
      cost: int.parse(row[3]),
    );
  }
}