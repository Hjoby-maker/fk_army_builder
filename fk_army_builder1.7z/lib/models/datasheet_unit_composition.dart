// models/datasheet_unit_composition.dart
class DatasheetUnitComposition {
  final String datasheetId;
  final int line;
  final String description;

  DatasheetUnitComposition({
    required this.datasheetId,
    required this.line,
    required this.description,
  });

  factory DatasheetUnitComposition.fromCSV(List<String> row) {
    return DatasheetUnitComposition(
      datasheetId: row[0],
      line: int.parse(row[1]),
      description: row[2],
    );
  }
}