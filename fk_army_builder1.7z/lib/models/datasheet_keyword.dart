// models/datasheet_keyword.dart
class DatasheetKeyword {
  final String datasheetId;
  final String keyword;
  final String? model;
  final bool isFactionKeyword;

  DatasheetKeyword({
    required this.datasheetId,
    required this.keyword,
    this.model,
    required this.isFactionKeyword,
  });

  factory DatasheetKeyword.fromCSV(List<String> row) {
    return DatasheetKeyword(
      datasheetId: row[0],
      keyword: row[1],
      model: row[2].isNotEmpty ? row[2] : null,
      isFactionKeyword: row[3].toLowerCase() == 'true',
    );
  }
}