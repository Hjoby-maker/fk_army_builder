// models/ability.dart
class Ability {
  final String id;
  final String name;
  final String legend;
  final String factionId;
  final String description;

  Ability({
    required this.id,
    required this.name,
    required this.legend,
    required this.factionId,
    required this.description,
  });

  factory Ability.fromCSV(List<String> row) {
    return Ability(
      id: row[0],
      name: row[1],
      legend: row[2],
      factionId: row[3],
      description: row[4],
    );
  }
}