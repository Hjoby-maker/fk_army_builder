// models/datasheet.dart
class Datasheet {
  final String id;
  final String name;
  final String factionId;
  final String sourceId;
  final String legend;
  final String role;
  final String loadout;
  final String transport;
  final bool virtual;
  final String? leaderHead;
  final String? leaderFooter;
  final String? damagedW;
  final String? damagedDescription;
  final String link;

  Datasheet({
    required this.id,
    required this.name,
    required this.factionId,
    required this.sourceId,
    required this.legend,
    required this.role,
    required this.loadout,
    required this.transport,
    required this.virtual,
    this.leaderHead,
    this.leaderFooter,
    this.damagedW,
    this.damagedDescription,
    required this.link,
  });

  factory Datasheet.fromCSV(List<String> row) {
    return Datasheet(
      id: row[0],
      name: row[1],
      factionId: row[2],
      sourceId: row[3],
      legend: row[4],
      role: row[5],
      loadout: row[6],
      transport: row[7],
      virtual: row[8].toLowerCase() == 'true',
      leaderHead: row[9].isNotEmpty ? row[9] : null,
      leaderFooter: row[10].isNotEmpty ? row[10] : null,
      damagedW: row[11].isNotEmpty ? row[11] : null,
      damagedDescription: row[12].isNotEmpty ? row[12] : null,
      link: row[13],
    );
  }
}