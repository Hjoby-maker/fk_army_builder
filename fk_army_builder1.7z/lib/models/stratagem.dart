// models/stratagem.dart
class Stratagem {
  final String? factionId;
  final String name;
  final String id;
  final String type;
  final int commandPointCost;
  final String legend;
  final String turn;
  final String phase;
  final String? detachment;
  final String? detachmentId;
  final String description;

  Stratagem({
    this.factionId,
    required this.name,
    required this.id,
    required this.type,
    required this.commandPointCost,
    required this.legend,
    required this.turn,
    required this.phase,
    this.detachment,
    this.detachmentId,
    required this.description,
  });

  factory Stratagem.fromCSV(List<String> row) {
    return Stratagem(
      factionId: row[0].isNotEmpty ? row[0] : null,
      name: row[1],
      id: row[2],
      type: row[3],
      commandPointCost: int.parse(row[4]),
      legend: row[5],
      turn: row[6],
      phase: row[7],
      detachment: row[8].isNotEmpty ? row[8] : null,
      detachmentId: row[9].isNotEmpty ? row[9] : null,
      description: row[10],
    );
  }
}