// models/datasheet_ability.dart
class DatasheetAbility {
  final String datasheetId;
  final int line;
  final String? abilityId;
  final String? model;
  final String? name;
  final String? description;
  final String? type;
  final String? parameter;

  DatasheetAbility({
    required this.datasheetId,
    required this.line,
    this.abilityId,
    this.model,
    this.name,
    this.description,
    this.type,
    this.parameter,
  });

  factory DatasheetAbility.fromCSV(List<String> row) {
    return DatasheetAbility(
      datasheetId: row[0],
      line: int.parse(row[1]),
      abilityId: row[2].isNotEmpty ? row[2] : null,
      model: row[3].isNotEmpty ? row[3] : null,
      name: row[4].isNotEmpty ? row[4] : null,
      description: row[5].isNotEmpty ? row[5] : null,
      type: row[6].isNotEmpty ? row[6] : null,
      parameter: row[7].isNotEmpty ? row[7] : null,
    );
  }
}