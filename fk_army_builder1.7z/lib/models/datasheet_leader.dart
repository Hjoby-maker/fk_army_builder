// models/datasheet_leader.dart
class DatasheetLeader {
  final String leaderId;
  final String attachedId;

  DatasheetLeader({
    required this.leaderId,
    required this.attachedId,
  });

  factory DatasheetLeader.fromCSV(List<String> row) {
    return DatasheetLeader(
      leaderId: row[0],
      attachedId: row[1],
    );
  }
}