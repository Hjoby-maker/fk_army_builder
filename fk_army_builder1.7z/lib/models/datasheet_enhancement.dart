// models/datasheet_enhancement.dart
class DatasheetEnhancement {
  final String datasheetId;
  final String enhancementId;

  DatasheetEnhancement({
    required this.datasheetId,
    required this.enhancementId,
  });

  factory DatasheetEnhancement.fromCSV(List<String> row) {
    return DatasheetEnhancement(
      datasheetId: row[0],
      enhancementId: row[1],
    );
  }
}