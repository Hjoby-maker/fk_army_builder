// models/source.dart
class Source {
  final String id;
  final String name;
  final String type;
  final String edition;
  final String version;
  final String errataDate;
  final String errataLink;

  Source({
    required this.id,
    required this.name,
    required this.type,
    required this.edition,
    required this.version,
    required this.errataDate,
    required this.errataLink,
  });

  factory Source.fromCSV(List<String> row) {
    // Убираем BOM символ если есть
    String id = row[0];
    if (id.startsWith('\uFEFF')) {
      id = id.substring(1);
    }
    
    return Source(
      id: id,
      name: row[1],
      type: row[2],
      edition: row[3],
      version: row[4],
      errataDate: row[5],
      errataLink: row[6],
    );
  }
}