// models/datasheet_stratagem.dart
class DatasheetStratagem {
  final String datasheetId;
  final String stratagemId;

  DatasheetStratagem({
    required this.datasheetId,
    required this.stratagemId,
  });

  factory DatasheetStratagem.fromCSV(List<String> row) {
    return DatasheetStratagem(
      datasheetId: row[0],
      stratagemId: row[1],
    );
  }
}