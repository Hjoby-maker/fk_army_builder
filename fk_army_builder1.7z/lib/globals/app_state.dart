// app_state.dart
import 'package:flutter/material.dart';
import 'constants.dart';

class AppState extends ChangeNotifier {
  // Singleton
  static final AppState _instance = AppState._internal();
  factory AppState() => _instance;
  AppState._internal();
  
  // Состояние приложения
  DateTime? _lastDataUpdate;
  String _currentLanguage = 'ru';
  ThemeMode _themeMode = ThemeMode.dark;
  int _maxArmyPoints = maxPointsDefault;
  Map<String, dynamic> _userPreferences = {};
  
  // Состояние загрузки данных
  Map<String, bool> _fileDownloadStatus = {};
  Map<String, int> _fileDownloadProgress = {};
  bool _isDownloading = false;
  int _totalFilesToDownload = csvFiles.length;
  int _filesDownloaded = 0;
  
  // Геттеры
  DateTime? get lastDataUpdate => _lastDataUpdate;
  String get currentLanguage => _currentLanguage;
  ThemeMode get themeMode => _themeMode;
  int get maxArmyPoints => _maxArmyPoints;
  bool get isDownloading => _isDownloading;
  int get totalFilesToDownload => _totalFilesToDownload;
  int get filesDownloaded => _filesDownloaded;
  double get downloadProgress => _totalFilesToDownload > 0 
      ? _filesDownloaded / _totalFilesToDownload 
      : 0;
  
  // Проверить статус конкретного файла
  bool isFileDownloaded(String fileName) => _fileDownloadStatus[fileName] ?? false;
  
  // Получить прогресс загрузки файла (0-100)
  int getFileProgress(String fileName) => _fileDownloadProgress[fileName] ?? 0;
  
  // Сеттеры
  set lastDataUpdate(DateTime? date) {
    _lastDataUpdate = date;
    notifyListeners();
  }
  
  set currentLanguage(String lang) {
    _currentLanguage = lang;
    notifyListeners();
  }
  
  set themeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners();
  }
  
  set maxArmyPoints(int points) {
    _maxArmyPoints = points;
    notifyListeners();
  }
  
  // Методы для управления состоянием загрузки
  
  void startDownload() {
    _isDownloading = true;
    _filesDownloaded = 0;
    _fileDownloadProgress.clear();
    notifyListeners();
  }
  
  void updateFileProgress(String fileName, int progress) {
    _fileDownloadProgress[fileName] = progress;
    notifyListeners();
  }
  
  void markFileAsDownloaded(String fileName, bool success) {
    _fileDownloadStatus[fileName] = success;
    _filesDownloaded++;
    notifyListeners();
  }
  
  void finishDownload() {
    _isDownloading = false;
    notifyListeners();
  }
  
  void resetDownloadStatus() {
    _fileDownloadStatus.clear();
    _fileDownloadProgress.clear();
    _filesDownloaded = 0;
    _isDownloading = false;
    notifyListeners();
  }
  
  // Проверить, все ли файлы загружены
  bool get allFilesDownloaded {
    if (_fileDownloadStatus.length < csvFiles.length) return false;
    return _fileDownloadStatus.values.every((status) => status == true);
  }
  
  // Получить список не загруженных файлов
  List<String> get missingFiles {
    return csvFiles.where((file) => !(_fileDownloadStatus[file] ?? false)).toList();
  }
  
  // Методы
  void updatePreference(String key, dynamic value) {
    _userPreferences[key] = value;
    notifyListeners();
  }
  
  dynamic getPreference(String key) {
    return _userPreferences[key];
  }
  
  void resetToDefaults() {
    _currentLanguage = 'ru';
    _themeMode = ThemeMode.dark;
    _maxArmyPoints = maxPointsDefault;
    _userPreferences.clear();
    resetDownloadStatus();
    notifyListeners();
  }
}