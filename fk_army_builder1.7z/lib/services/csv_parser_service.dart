//import 'dart:convert';
import '../models/index.dart';
import '../globals/constants.dart';
import './helper/html_cleaner.dart';
// csv_parser_service.dart
class CSVParserService {

  dynamic parseCSVByFileName(String fileName, String csvString) {
  // Проверяем, что файл в списке поддерживаемых
  if (!csvFiles.contains(fileName)) {
    throw Exception('Файл $fileName не поддерживается');
  }
  switch (fileName) {
    case 'Factions.csv': return parseFactionsFromCSV(csvString);
    case 'Abilities.csv': return parseAbilitiesFromCSV(csvString);
    case 'Datasheets.csv': return parseDatasheetsFromCSV(csvString);
    case 'Detachments.csv': return parseDetachmentsFromCSV(csvString);
    case 'Enhancements.csv': return parseEnhancementsFromCSV(csvString);
    case 'Source.csv': return parseSourcesFromCSV(csvString);
    case 'Stratagems.csv': return parseStratagemsFromCSV(csvString);
    case 'Detachment_abilities.csv': return parseDetachmentAbilitiesFromCSV(csvString);
    case 'Last_update.csv': return parseLastUpdateFromCSV(csvString);
    case 'Datasheets_abilities.csv': return parseDatasheetAbilitiesFromCSV(csvString);
    case 'Datasheets_detachment_abilities.csv': return parseDatasheetDetachmentAbilitiesFromCSV(csvString);
    case 'Datasheets_enhancements.csv': return parseDatasheetEnhancementsFromCSV(csvString);
    case 'Datasheets_keywords.csv': return parseDatasheetKeywordsFromCSV(csvString);
    case 'Datasheets_leader.csv': return parseDatasheetLeadersFromCSV(csvString);
    case 'Datasheets_models.csv': return parseDatasheetModelsFromCSV(csvString);
    case 'Datasheets_models_cost.csv': return parseDatasheetModelCostsFromCSV(csvString);
    case 'Datasheets_options.csv': return parseDatasheetOptionsFromCSV(csvString);
    case 'Datasheets_stratagems.csv': return parseDatasheetStratagemsFromCSV(csvString);
    case 'Datasheets_unit_composition.csv': return parseDatasheetUnitCompositionsFromCSV(csvString);
    case 'Datasheets_wargear.csv': return parseDatasheetWargearFromCSV(csvString);
    default: throw Exception('Парсер для файла $fileName не реализован');
    }
  }

  List<Faction> parseFactionsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Faction.fromCSV(row)).toList();
  }
  
  List<Ability> parseAbilitiesFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Ability.fromCSV(row)).toList();
  }
  
  List<Datasheet> parseDatasheetsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Datasheet.fromCSV(row)).toList();
  }
  
  List<Detachment> parseDetachmentsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Detachment.fromCSV(row)).toList();
  }
  
  List<Enhancement> parseEnhancementsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Enhancement.fromCSV(row)).toList();
  }
  
  List<Source> parseSourcesFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Source.fromCSV(row)).toList();
  }
  
  List<Stratagem> parseStratagemsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => Stratagem.fromCSV(row)).toList();
  }
  
  List<DetachmentAbility> parseDetachmentAbilitiesFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DetachmentAbility.fromCSV(row)).toList();
  }
  
  List<LastUpdate> parseLastUpdateFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => LastUpdate.fromCSV(row)).toList();
  }
  
  List<DatasheetAbility> parseDatasheetAbilitiesFromCSV(String csvString) {

    final rows = parseCSV(csvString);
    final result = <DatasheetAbility>[];
    
    for (int i = 0; i < rows.length; i++) {
      final row = rows[i];
      if (row.length < 8) {

        print('Пропущена строка ${i + 1}: недостаточно колонок (${row.length})');
        print('Данные строки: $row');
        continue;
      }
      
      try {
        final datasheetAbility = DatasheetAbility.fromCSV(row);
        result.add(datasheetAbility);
        //print('Данные $i строки добавлены');
      } catch (e) {
        print('Ошибка парсинга DatasheetAbility строка ${i + 1}: $e');
        print('Данные строки: $row');
      }
    }

    return result;
    //return rows.map((row) => DatasheetAbility.fromCSV(row)).toList();
  }
  
  List<DatasheetDetachmentAbility> parseDatasheetDetachmentAbilitiesFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetDetachmentAbility.fromCSV(row)).toList();
  }
  
  List<DatasheetEnhancement> parseDatasheetEnhancementsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetEnhancement.fromCSV(row)).toList();
  }
  
  List<DatasheetKeyword> parseDatasheetKeywordsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetKeyword.fromCSV(row)).toList();
  }
  
  List<DatasheetLeader> parseDatasheetLeadersFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetLeader.fromCSV(row)).toList();
  }
  
  List<DatasheetModel> parseDatasheetModelsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetModel.fromCSV(row)).toList();
  }
  
  List<DatasheetModelCost> parseDatasheetModelCostsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetModelCost.fromCSV(row)).toList();
  }
  
  List<DatasheetOption> parseDatasheetOptionsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetOption.fromCSV(row)).toList();
  }
  
  List<DatasheetStratagem> parseDatasheetStratagemsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetStratagem.fromCSV(row)).toList();
  }
  
  List<DatasheetUnitComposition> parseDatasheetUnitCompositionsFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetUnitComposition.fromCSV(row)).toList();
  }
  
  List<DatasheetWargear> parseDatasheetWargearFromCSV(String csvString) {
    final rows = parseCSV(csvString);
    return rows.map((row) => DatasheetWargear.fromCSV(row)).toList();
  }
  
  // Базовый парсер CSV с разделителем |
  List<List<String>> parseCSV(String csvString, {String delimiter = '|'}) {
    final lines = csvString.split('\n');
    final result = <List<String>>[];
    
    for (final line in lines) {
      if (line.trim().isEmpty) continue;
        print(line);
        String cleanline = HtmlCleaner.clean(line);
        print(cleanline);
      // Обработка кавычек и экранирования
       try {
        final row = _parseCSVLine(cleanline, delimiter);
        result.add(row);
      } catch (e) {
        print('Ошибка парсинга строки ${cleanline.length+ 1}: $e');
        print('Содержимое строки: "$cleanline"');
        // Пропускаем проблемную строку или добавляем пустую
        result.add([]);
      }
    }
    
    return result;
  }
  
  List<String> _parseCSVLine(String line, String delimiter) {
    final result = <String>[];
    StringBuffer current = StringBuffer();
    bool inQuotes = false;
    bool escapeNext = false;
    
    for (int i = 0; i < line.length; i++) {
      final char = line[i];
      if (escapeNext) {
        current.write(char);
        escapeNext = false;
        continue;
      }

      if (char == '\\') {
        escapeNext = true;
        continue;
      }

      /*if (char == '"') {
        // Проверяем, не является ли это экранированной кавычкой
        if (i + 1 < line.length && line[i + 1] == '"') {
          current.write('"');
          i++; // Пропускаем следующую кавычку
        } else {
          inQuotes = !inQuotes;
        }
      } else*/ if (char == delimiter && !inQuotes) {
        result.add(current.toString().trim());
        current.clear();
      } else {
        current.write(char);
      }
     // print(char);
     // print(inQuotes.toString());
     // print(current.toString());
    }
    
    // Добавляем последнее значение
    result.add(current.toString());
    
    return result;
  }
}